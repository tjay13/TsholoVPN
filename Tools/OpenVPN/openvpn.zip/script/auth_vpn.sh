#!/bin/bash
username=`head -n1 $1 | tail -1`   
password=`head -n2 $1 | tail -1`
tm="$(date +%s)"
dt="$(date +'%Y-%m-%d %H:%M:%S')"

HOST='185.61.137.174'
USER='vpnquest1_user'
PASS='s+(WT#r4CaB&'
DB='vpnquest1_dbase'


PRE="user.username='$username' AND user.auth_vpn=md5('$password') AND user.confirmcode='y' AND user.status='live' AND user.is_freeze=1 AND user.is_active=1 AND user.is_ban=1 AND user.is_suspend=1 AND user.is_duration > 0"
Query="SELECT user.username FROM user WHERE $PRE"
auth_vpn=`mysql -u $USER -p$PASS -D $DB -h $HOST --skip-column-name -e "$Query"`

if [ "$auth_vpn" == "$username" ]; then
    echo "user : $username"
	echo "authentication ok."
	exit 0
else
    echo "authentication failed."
	exit 1
fi